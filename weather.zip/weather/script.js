// API Key
const apiKey = "3cd84f36cfa83ee103ec778bb980de92";  // Replace with your actual API key

// Get DOM elements
const cityInput = document.getElementById('city');
const weatherInfoDiv = document.getElementById('weatherInfo');

// Get weather function
function getWeather() {
    const city = cityInput.value.trim(); // Get the city name from input

    if (!city) {
        weatherInfoDiv.innerHTML = '<p class="error">Please enter a city name!</p>';
        weatherInfoDiv.style.display = 'block';
        return;
    }

    // Build the API URL using the city name and API key
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=en`;

    // Fetch data from API
    fetch(apiUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error('City not found or something went wrong');
            }
            return response.json();
        })
        .then(data => {
            console.log(data); // Check data in Console

            const temp = data.main.temp;
            const description = data.weather[0].description;
            const icon = data.weather[0].icon;
            const iconUrl = `https://openweathermap.org/img/wn/${icon}@2x.png`;

            // Display weather info on the UI
            weatherInfoDiv.innerHTML = `
                <h2>Weather in ${city}</h2>
                <p>Temperature: ${temp}°C</p>
                <p>Condition: ${description}</p>
                <img src="${iconUrl}" alt="Weather Icon">
            `;

            weatherInfoDiv.style.display = 'block'; // Show weather info
        })
        .catch(error => {
            weatherInfoDiv.innerHTML = `<p class="error">${error.message}</p>`;
            weatherInfoDiv.style.display = 'block'; // Show error message
        });
}

// Attach event to "Enter" key on input field
cityInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        getWeather();  // Call function on "Enter" key
    }
});
